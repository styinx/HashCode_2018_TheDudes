class Info:
    def __init__(self, rows, cols, cars, rides, bonus, sim_time):
        self.rows = rows
        self.cols = cols
        self.cars = cars
        self.rides = rides
        self.bonus = bonus
        self.sim_time = sim_time